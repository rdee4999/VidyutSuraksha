package in.vidyutsuraksha.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.platform.LocalContext

private val Navy = Color(0xFF0B1F33)
private val Blue = Color(0xFF155EEF)
private val Pale = Color(0xFFF3F6FB)
private val Teal = Color(0xFF0D9488)

data class Lesson(val icon: String, val title: String, val summary: String, val points: List<Pair<String,String>>)
private val lessons = listOf(
    Lesson("🔌","Plugs, sockets & appliances","Use electricity without overloading or damaging equipment.", listOf(
        "Check before use" to "Do not use cracked plugs, frayed cords, exposed wires or loose sockets.",
        "Keep dry" to "Keep hands dry and electrical appliances away from water.",
        "Avoid overloading" to "Do not overload sockets or extension boards. Stay within rated capacity.",
        "Switch off safely" to "Unplug by holding the plug, not pulling the cord."
    )),
    Lesson("🛡️","Earthing & protective devices","Understand earthing, MCBs and RCCBs/RCDs.", listOf(
        "Earthing" to "Protective earthing provides a path for fault current and must be correctly installed.",
        "MCB" to "An MCB protects wiring against overcurrent and short circuits; it does not alone provide all shock protection.",
        "RCCB/RCD" to "An RCCB/RCD detects certain leakage currents, but does not replace earthing or safe behaviour.",
        "Never bypass" to "Never bypass a protective device or repeatedly reset one that trips."
    )),
    Lesson("🏠","Safe wiring at home","Recognise warning signs and arrange safe repairs.", listOf(
        "Warning signs" to "Burning smell, sparks, hot switches, buzzing or repeated tripping need prompt attention.",
        "Repairs" to "Do not carry out live electrical work. Use a qualified electrician.",
        "Children" to "Keep cords out of reach and teach children never to insert objects into sockets.",
        "Temporary wiring" to "Avoid damaged extension leads, loose joints and cords under rugs."
    )),
    Lesson("⚡","Overhead lines & outdoor safety","Stay away from overhead lines and fallen conductors.", listOf(
        "Keep distance" to "Never approach or touch overhead electrical lines.",
        "Fallen wires" to "Assume a fallen conductor is live. Keep away and call the electricity utility/emergency services.",
        "Ladders and kites" to "Keep ladders, long objects and kites well clear of power lines.",
        "Construction" to "Never work near electrical infrastructure without authorised safety arrangements."
    )),
    Lesson("🏢","Workplace & electrical isolation","Core principles for safe work around electrical systems.", listOf(
        "Authorisation" to "Only trained and authorised persons should perform electrical work.",
        "Isolation and LOTO" to "Identify energy sources, isolate, lock and tag per site procedures, then verify absence of voltage.",
        "PPE and tools" to "Use inspected, task-appropriate PPE and insulated tools.",
        "No assumptions" to "Never assume equipment is de-energised just because a switch is off."
    )),
    Lesson("🔥","Electrical fire & emergency response","Protect people first during an incident.", listOf(
        "Raise alarm" to "Evacuate people, alert others and call emergency services.",
        "Do not use water" to "Never apply water to equipment that may be energised.",
        "Shock response" to "Do not touch a casualty until the source is safely isolated.",
        "Report hazards" to "Report damaged equipment, near misses and incidents promptly."
    ))
)
data class Question(val prompt: String, val options: List<String>, val answer: Int, val explanation: String)
private val questions = listOf(
    Question("You notice a frayed power cord. What should you do?", listOf("Wrap it in paper","Stop using it and arrange safe replacement","Keep using it if it works"),1,"Damaged cords can expose live conductors and cause shock or fire."),
    Question("An RCCB/RCD trips repeatedly. What is safest?",listOf("Bypass it","Fit a larger fuse without checking","Stop resetting it and ask a qualified electrician"),2,"Repeated tripping can indicate a fault. Never bypass protection."),
    Question("A person may be receiving an electric shock. What should you do first?",listOf("Grab their hand","Avoid touching them; isolate power only if safe and call for help","Pour water nearby"),1,"You could become a second casualty if the source is live."),
    Question("You see a fallen overhead wire. What should you do?",listOf("Move it with a stick","Keep away and report it as live","Walk over it carefully"),1,"Fallen wires can remain energised."),
    Question("What is an MCB primarily designed to protect against?",listOf("All electric shocks","Overcurrent and short circuits","Every electrical fire"),1,"An MCB does not replace an RCD or earthing."),
    Question("Before electrical maintenance, what is essential?",listOf("Assume the switch is enough","Follow isolation/lockout procedures and verify absence of voltage","Wear rubber-soled shoes only"),1,"Safe work requires controlled isolation and verification.")
)
private val checkItems = listOf(
    "No frayed cords, cracked plugs or exposed wires",
    "Sockets and extension boards are not overloaded",
    "No hot switches, sparks or burning smells",
    "Electrical equipment is kept away from water",
    "Protective devices are not bypassed; repeated tripping is investigated"
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { VidyutApp() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun VidyutApp() {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("vs_progress", 0) }
    val completed = remember { mutableStateListOf<Int>().apply { addAll(prefs.getStringSet("lessons", emptySet())!!.mapNotNull { it.toIntOrNull() }) } }
    val checked = remember { mutableStateListOf<Int>().apply { addAll(prefs.getStringSet("checks", emptySet())!!.mapNotNull { it.toIntOrNull() }) } }
    var score by remember { mutableIntStateOf(prefs.getInt("score",0)) }
    var tab by remember { mutableStateOf("Home") }
    var lessonIndex by remember { mutableIntStateOf(-1) }
    var quizIndex by remember { mutableIntStateOf(-1) }
    var qIndex by remember { mutableIntStateOf(0) }
    var selected by remember { mutableIntStateOf(-1) }
    var quizScore by remember { mutableIntStateOf(0) }
    var quizDone by remember { mutableStateOf(false) }
    fun persist() {
        prefs.edit().putStringSet("lessons", completed.map { it.toString() }.toSet())
            .putStringSet("checks", checked.map { it.toString() }.toSet()).putInt("score", score).apply()
    }
    MaterialTheme(colorScheme = lightColorScheme(primary=Blue, secondary=Teal, background=Pale)) {
        Scaffold(
            containerColor = Pale,
            topBar = {
                if (lessonIndex < 0 && quizIndex < 0) TopAppBar(
                    title = { Column { Text("⚡ Vidyut Suraksha", fontWeight=FontWeight.Bold, color=Color.White); Text("Electrical safety learning", fontSize=12.sp, color=Color(0xFFD5E5F5)) } },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor=Navy)
                )
            },
            bottomBar = {
                NavigationBar(containerColor=Color.White) {
                    listOf("Home","Learn","Quiz","Check","Progress").forEach { name ->
                        NavigationBarItem(selected=tab==name, onClick={
                            tab=name; lessonIndex=-1; quizIndex=-1; quizDone=false
                        }, icon={
                            when(name) {
                                "Home" -> Icon(Icons.Default.Home, null)
                                "Learn" -> Icon(Icons.Default.MenuBook, null)
                                "Quiz" -> Icon(Icons.Default.Quiz, null)
                                "Check" -> Icon(Icons.Default.CheckCircle, null)
                                else -> Icon(Icons.Default.Insights, null)
                            }
                        }, label={ Text(name) })
                    }
                }
            }
        ) { padding ->
            if (lessonIndex >= 0) LessonScreen(lessons[lessonIndex], completed.contains(lessonIndex), Modifier.padding(padding), onBack={lessonIndex=-1;tab="Learn"}, onComplete={
                if (!completed.contains(lessonIndex)) completed.add(lessonIndex)
                persist()
            })
            else if (quizIndex >= 0) QuizScreen(qIndex, selected, quizDone, quizScore, Modifier.padding(padding),
                onSelect={ selected=it },
                onNext={
                    if (selected == questions[qIndex].answer) quizScore++
                    if (qIndex < questions.lastIndex) { qIndex++; selected=-1 }
                    else { score += quizScore; persist(); quizDone=true }
                },
                onRetry={ qIndex=0;selected=-1;quizScore=0;quizDone=false })
            else when(tab) {
                "Home" -> HomeScreen(completed.size, score, checked.size, Modifier.padding(padding),
                    onLearn={tab="Learn"}, onQuiz={tab="Quiz";quizIndex=0;qIndex=0;selected=-1;quizScore=0;quizDone=false},
                    onCheck={tab="Check"}, onEmergency={tab="Emergency"})
                "Learn" -> LessonsScreen(completed, Modifier.padding(padding), onOpen={lessonIndex=it})
                "Quiz" -> { LaunchedEffect(tab) { if (quizIndex < 0) { quizIndex=0;qIndex=0;selected=-1;quizScore=0;quizDone=false } }; Box(Modifier.padding(padding)) { } }
                "Check" -> ChecklistScreen(checked, Modifier.padding(padding), onToggle={i,on -> if(on && !checked.contains(i))checked.add(i) else if(!on)checked.remove(i);persist()})
                "Progress" -> ProgressScreen(completed.size, score, checked.size, Modifier.padding(padding))
                "Emergency" -> EmergencyScreen(Modifier.padding(padding))
                else -> HomeScreen(completed.size,score,checked.size,Modifier.padding(padding),{tab="Learn"},{tab="Quiz";quizIndex=0},{tab="Check"},{tab="Emergency"})
            }
        }
    }
}

@Composable
fun HomeScreen(done:Int, score:Int, checks:Int, modifier:Modifier, onLearn:()->Unit, onQuiz:()->Unit, onCheck:()->Unit, onEmergency:()->Unit) {
    LazyColumn(modifier.fillMaxSize().padding(16.dp), verticalArrangement=Arrangement.spacedBy(12.dp)) {
        item {
            Card(colors=CardDefaults.cardColors(containerColor=Navy), shape=MaterialTheme.shapes.extraLarge) {
                Column(Modifier.padding(20.dp)) {
                    Text("LEARN SAFE. STAY SAFE.", color=Color(0xFFFBBF24), fontSize=12.sp, fontWeight=FontWeight.Bold)
                    Spacer(Modifier.height(8.dp)); Text("Electrical safety starts with you.", color=Color.White, fontSize=25.sp, fontWeight=FontWeight.Bold)
                    Spacer(Modifier.height(8.dp)); Text("Short lessons, practical checks and quick quizzes.", color=Color(0xFFD5E5F5))
                    Spacer(Modifier.height(18.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.SpaceBetween) {
                        Stat("$done/6","Lessons"); Stat("$score","Quiz points"); Stat("$checks/5","Checks")
                    }
                }
            }
        }
        item { Text("Start learning", fontSize=20.sp, fontWeight=FontWeight.Bold) }
        item { FeatureCard("📘","Safety lessons","Six bite-sized topics",onLearn) }
        item { FeatureCard("🧠","Quick quiz","Test your knowledge",onQuiz) }
        item { FeatureCard("✅","Home safety check","Check common household hazards",onCheck) }
        item { FeatureCard("🚨","Emergency guide","Shock, fire and fallen wires",onEmergency) }
        item { SafetyNotice("Never touch a person who may still be in contact with electricity. Isolate power only if safe, keep away and call emergency services.") }
    }
}
@Composable fun Stat(value:String,label:String) { Column { Text(value,color=Color.White,fontWeight=FontWeight.Bold,fontSize=20.sp);Text(label,color=Color(0xFFD5E5F5),fontSize=11.sp) } }
@Composable fun FeatureCard(emoji:String,title:String,desc:String,onClick:()->Unit) {
    Card(Modifier.fillMaxWidth().clickable(onClick=onClick), colors=CardDefaults.cardColors(containerColor=Color.White), elevation=CardDefaults.cardElevation(1.dp)) {
        Row(Modifier.padding(16.dp), verticalAlignment=Alignment.CenterVertically) {
            Text(emoji,fontSize=28.sp); Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) { Text(title,fontWeight=FontWeight.Bold,fontSize=16.sp); Text(desc,color=Color.Gray,fontSize=13.sp) }
            Icon(Icons.Default.ChevronRight,null,tint=Blue)
        }
    }
}
@Composable fun SafetyNotice(text:String) {
    Card(colors=CardDefaults.cardColors(containerColor=Color(0xFFFFF4D6))) { Row(Modifier.padding(14.dp)) { Icon(Icons.Default.Warning,null,tint=Color(0xFF9A6700)); Spacer(Modifier.width(8.dp)); Text(text,color=Color(0xFF7A4B00),fontSize=13.sp) } }
}
@Composable fun LessonsScreen(completed:List<Int>, modifier:Modifier, onOpen:(Int)->Unit) {
    LazyColumn(modifier.fillMaxSize().padding(16.dp),verticalArrangement=Arrangement.spacedBy(10.dp)) {
        item { Text("Learning modules",fontSize=23.sp,fontWeight=FontWeight.Bold); Text("Choose a topic to study.",color=Color.Gray) }
        itemsIndexed(lessons) { i,l ->
            Card(Modifier.fillMaxWidth().clickable { onOpen(i) }, colors=CardDefaults.cardColors(containerColor=Color.White)) {
                Row(Modifier.padding(15.dp),verticalAlignment=Alignment.CenterVertically) {
                    Text(l.icon,fontSize=26.sp);Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) { Text(l.title,fontWeight=FontWeight.Bold);Text(l.summary,fontSize=13.sp,color=Color.Gray) }
                    if(completed.contains(i)) Icon(Icons.Default.CheckCircle,null,tint=Teal) else Icon(Icons.Default.ChevronRight,null)
                }
            }
        }
    }
}
@Composable fun LessonScreen(lesson:Lesson, isDone:Boolean, modifier:Modifier, onBack:()->Unit, onComplete:()->Unit) {
    Column(modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
        Text("← All lessons",color=Blue,fontWeight=FontWeight.Bold,modifier=Modifier.clickable(onClick=onBack))
        Spacer(Modifier.height(16.dp));Text(lesson.icon,fontSize=38.sp);Text(lesson.title,fontSize=25.sp,fontWeight=FontWeight.Bold)
        Spacer(Modifier.height(8.dp));Text(lesson.summary,color=Color.Gray)
        lesson.points.forEachIndexed { i,p ->
            Card(Modifier.fillMaxWidth().padding(top=10.dp),colors=CardDefaults.cardColors(containerColor=Color.White)) {
                Column(Modifier.padding(16.dp)) { Text("${i+1}. ${p.first}",fontWeight=FontWeight.Bold);Spacer(Modifier.height(5.dp));Text(p.second) }
            }
        }
        Spacer(Modifier.height(18.dp));Button(onClick=onComplete,modifier=Modifier.fillMaxWidth()) { Text(if(isDone)"Lesson reviewed ✓" else "Mark lesson explored ✓") }
    }
}
@Composable fun QuizScreen(index:Int, selected:Int, done:Boolean, finalScore:Int, modifier:Modifier, onSelect:(Int)->Unit, onNext:()->Unit, onRetry:()->Unit) {
    Column(modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
        if(done) {
            Text("🏆",fontSize=42.sp);Text("Quiz complete!",fontSize=25.sp,fontWeight=FontWeight.Bold)
            Text("Your score: $finalScore / ${questions.size}",fontSize=18.sp)
            Spacer(Modifier.height(12.dp));Button(onClick=onRetry,modifier=Modifier.fillMaxWidth()){Text("Try again")}
            Text("Answer review",fontWeight=FontWeight.Bold,fontSize=20.sp,modifier=Modifier.padding(top=18.dp))
            questions.forEachIndexed { i,q -> Card(Modifier.fillMaxWidth().padding(top=8.dp),colors=CardDefaults.cardColors(containerColor=Color.White)) { Column(Modifier.padding(14.dp)){Text("${i+1}. ${q.prompt}",fontWeight=FontWeight.Bold);Text("Correct: ${q.options[q.answer]}");Text(q.explanation,color=Color.Gray,fontSize=13.sp)} } }
        } else {
            Text("Quick quiz",fontSize=24.sp,fontWeight=FontWeight.Bold);Text("Question ${index+1} of ${questions.size}",color=Color.Gray)
            LinearProgressIndicator(progress={ (index+1).toFloat()/questions.size },modifier=Modifier.fillMaxWidth().padding(vertical=12.dp))
            Text(questions[index].prompt,fontSize=19.sp,fontWeight=FontWeight.Bold)
            questions[index].options.forEachIndexed { i,option ->
                Card(Modifier.fillMaxWidth().padding(top=10.dp).clickable { onSelect(i) },colors=CardDefaults.cardColors(containerColor=if(selected==i)Color(0xFFEAF2FF) else Color.White)) {
                    Row(Modifier.padding(14.dp),verticalAlignment=Alignment.CenterVertically) { RadioButton(selected==i,onClick={onSelect(i)});Spacer(Modifier.width(8.dp));Text(option) }
                }
            }
            Spacer(Modifier.height(18.dp));Button(onClick=onNext,enabled=selected>=0,modifier=Modifier.fillMaxWidth()){Text(if(index==questions.lastIndex)"Finish quiz" else "Next question →")}
        }
    }
}
@Composable fun ChecklistScreen(checked:List<Int>, modifier:Modifier, onToggle:(Int,Boolean)->Unit) {
    Column(modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
        Text("Home safety check",fontSize=24.sp,fontWeight=FontWeight.Bold);Text("If you find a defect, stop using the equipment and contact a qualified electrician.",color=Color.Gray)
        Spacer(Modifier.height(10.dp))
        checkItems.forEachIndexed { i,item ->
            Card(Modifier.fillMaxWidth().padding(vertical=5.dp),colors=CardDefaults.cardColors(containerColor=Color.White)) {
                Row(Modifier.padding(12.dp),verticalAlignment=Alignment.CenterVertically) { Checkbox(checked.contains(i),onCheckedChange={onToggle(i,it)});Spacer(Modifier.width(8.dp));Text(item) }
            }
        }
        Spacer(Modifier.height(12.dp));LinearProgressIndicator(progress={checked.size/5f},modifier=Modifier.fillMaxWidth());Text("${checked.size} of 5 completed",color=Color.Gray)
    }
}
@Composable fun EmergencyScreen(modifier:Modifier) {
    Column(modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
        Text("Electrical emergency guide",fontSize=24.sp,fontWeight=FontWeight.Bold)
        SafetyNotice("Life-threatening emergency: keep away from the hazard. In India, call 112 for emergency assistance where appropriate.")
        EmergencyCard("⚡ Electric shock",listOf("Do not touch the person while they may be in contact with a live source.","Turn off supply only if safe to do so.","Call emergency services. Once safe, follow dispatcher instructions for CPR/AED if trained."))
        EmergencyCard("🔥 Electrical fire",listOf("Raise the alarm, evacuate and call emergency services.","Never throw water on equipment that may be live.","Use an extinguisher only if trained, suitable and you have a clear escape route."))
        EmergencyCard("⚠️ Fallen wire",listOf("Treat every fallen wire as live. Keep well away and warn others.","Do not touch the wire, nearby objects or anyone in contact with it.","Contact the electricity utility and emergency services."))
        Text("General awareness only; follow local emergency procedures and formal training.",color=Color.Gray,fontSize=12.sp,modifier=Modifier.padding(top=12.dp))
    }
}
@Composable fun EmergencyCard(title:String,points:List<String>) {
    Card(Modifier.fillMaxWidth().padding(vertical=6.dp),colors=CardDefaults.cardColors(containerColor=Color.White)) {
        Column(Modifier.padding(15.dp)) { Text(title,fontWeight=FontWeight.Bold,fontSize=17.sp);points.forEach { Text("• $it",modifier=Modifier.padding(top=7.dp),fontSize=14.sp) } }
    }
}
@Composable fun ProgressScreen(done:Int, score:Int, checks:Int, modifier:Modifier) {
    Column(modifier.fillMaxSize().padding(16.dp)) {
        Text("Your progress",fontSize=24.sp,fontWeight=FontWeight.Bold)
        Card(Modifier.fillMaxWidth().padding(top=12.dp),colors=CardDefaults.cardColors(containerColor=Color.White)) {
            Column(Modifier.padding(18.dp)) {
                Text("Learning summary",fontWeight=FontWeight.Bold,fontSize=18.sp)
                Text("$done of 6 lessons explored",modifier=Modifier.padding(top=12.dp))
                LinearProgressIndicator(progress={done/6f},modifier=Modifier.fillMaxWidth().padding(vertical=6.dp))
                Text("$score quiz points",modifier=Modifier.padding(top=8.dp))
                Text("$checks of 5 home safety checks completed",modifier=Modifier.padding(top=8.dp))
                LinearProgressIndicator(progress={checks/5f},modifier=Modifier.fillMaxWidth().padding(vertical=6.dp))
                Text("Progress is saved on this device.",color=Color.Gray,fontSize=12.sp,modifier=Modifier.padding(top=8.dp))
            }
        }
    }
}
